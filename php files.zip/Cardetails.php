<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$carId = $_GET['id'];

$sql = "SELECT Name, Description, Color, Price, Image1, Image2, Image3, Image4, Image5 FROM Car WHERE ID = $carId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $carDetails = $result->fetch_assoc();
    $imageUrls = [];
    $baseUrl = "https://carrentalisddatabaseh.000webhostapp.com/CarsIcons/";
    for ($i = 1; $i <= 5; $i++) {
        $imageColumn = 'Image' . $i;
        if (!empty($carDetails[$imageColumn])) {
            $imageUrls[] = $baseUrl . $carDetails[$imageColumn];
        }
    }
    $carDetails['ImageUrls'] = $imageUrls;

    echo json_encode($carDetails);
} else {
    echo json_encode(['error' => 'Car not found']);
}

$conn->close();
?>

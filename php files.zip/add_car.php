<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$name = $_POST['name'];
$description = $_POST['description'];
$color = $_POST['color'];
$price = $_POST['price'];
$imageFileNames = json_decode($_POST['images']); 
function generateUniqueId($conn) {
    do {
        $uniqueId = rand(1, 99999);
        $sql = "SELECT * FROM Car WHERE ID = '$uniqueId'";
        $result = $conn->query($sql);
    } while ($result && $result->num_rows > 0);
    return $uniqueId;
}
$uniqueId = generateUniqueId($conn);
$sql = "INSERT INTO Car (ID, Name, Description, Color, Price";
for ($i = 1; $i <= count($imageFileNames); $i++) {
    $sql .= ", Image$i";
}

$sql .= ") VALUES ('$uniqueId', '$name', '$description', '$color', '$price'";
foreach ($imageFileNames as $index => $imageFileName) {
    $sql .= ", '$imageFileName'";
}

$sql .= ")";

if ($conn->query($sql) === TRUE) {
    echo "Car details and image file names inserted successfully";
} else {
    echo "Error inserting car details: " . $conn->error;
}

$conn->close();
?>

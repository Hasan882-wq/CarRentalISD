<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$customerId = $_POST['customerId'];
$sql = "SELECT SUM(Price) as Total_Sales, COUNT(*) as Number_Of_Reservations FROM Reservation_History WHERE CID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $customerId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalSales = $row['Total_Sales'];
    $numberOfReservations = $row['Number_Of_Reservations'];
} else {
    $totalSales = 0;
    $numberOfReservations = 0;
}

$stmt->close();
$sql = "SELECT RH.ID, RH.Days, RH.Price, RH.CID, RH.RID, C.Image1 FROM Reservation_History RH
        JOIN Car C ON RH.RID = C.ID WHERE RH.CID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $customerId);
$stmt->execute();
$result = $stmt->get_result();

$reservations = [];
$baseUrl = 'https://carrentalisddatabaseh.000webhostapp.com/CarsIcons/'; 
while ($row = $result->fetch_assoc()) {
    $row['Image1'] = $baseUrl . $row['Image1'];
    $reservations[] = $row;
}

$stmt->close();
$conn->close();

$response = [
    'total_sales' => $totalSales,
    'number_of_reservations' => $numberOfReservations,
    'reservations' => $reservations,
];

echo json_encode($response);
?>

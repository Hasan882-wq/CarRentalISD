<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Car.ID, Car.Name, Car.Price, Car.Image1, 
        (SELECT COUNT(*) FROM Out_Of_Order WHERE Out_Of_Order.CID = Car.ID) as out_of_order,
        (SELECT COUNT(*) FROM Reservation WHERE Reservation.RID = Car.ID) as reserved,
        (SELECT COUNT(*) FROM Pending WHERE Pending.RID = Car.ID) as pending
        FROM Car";
$result = $conn->query($sql);

$cars = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $imageFilename = $row['Image1'];
        $imagePath = 'https://carrentalisddatabaseh.000webhostapp.com/CarsIcons/' . $imageFilename;
        $carData = array(
            'ID' => $row['ID'],
            'Name' => $row['Name'],
            'Price' => $row['Price'],
            'Image1' => $imagePath,
            'OutOfOrder' => $row['out_of_order'] > 0 ? true : false,
            'Reserved' => $row['reserved'] > 0 ? true : false,
            'Pending' => $row['pending'] > 0 ? true : false
        );
        if (!$carData['OutOfOrder'] && !$carData['Reserved'] && !$carData['Pending']) {
            $cars[] = $carData;
        }
    }
}
echo json_encode($cars);

$conn->close();
?>

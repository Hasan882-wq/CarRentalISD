<?php
$hostname = "localhost";
$database = "id22161597_carrentaldatabase";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$conn = new mysqli($hostname, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$carId = isset($_POST['carId']) ? $conn->real_escape_string($_POST['carId']) : '';
$reason = isset($_POST['reason']) ? $conn->real_escape_string($_POST['reason']) : '';
if (empty($carId) || empty($reason)) {
    die("Car ID and reason are required.");
}
function generateUniqueId($conn) {
    do {
        $uniqueId = rand(1, 99999);
        $sql = "SELECT * FROM Out_Of_Order WHERE ID = '$uniqueId'";
        $result = $conn->query($sql);
    } while ($result && $result->num_rows > 0);
    return $uniqueId;
}

$uniqueId = generateUniqueId($conn);
$sql = "INSERT INTO Out_Of_Order VALUES ('$uniqueId', '$reason','$carId')";

if ($conn->query($sql) === TRUE) {
    echo "Record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

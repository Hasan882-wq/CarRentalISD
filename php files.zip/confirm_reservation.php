<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reservationId = $_POST['reservationId'];
$carId = $_POST['carId'];
$customerId = $_POST['customerId'];
$days = $_POST['days'];
$newPrice = $_POST['price'];
function generateUniqueId($conn) {
    do {
        $uniqueId = rand(1, 999999);
        $stmt = $conn->prepare("SELECT COUNT(*) FROM Reservation WHERE ID = ?");
        $stmt->bind_param("i", $uniqueId);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
    } while ($count > 0);

    return $uniqueId;
}
$conn->begin_transaction();

try {
    $uniqueId = generateUniqueId($conn);
    $stmt = $conn->prepare("INSERT INTO Reservation (Id, RID, CID, Days, Price) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iiisi", $uniqueId, $carId, $customerId, $days, $newPrice);

    if (!$stmt->execute()) {
        throw new Exception("Failed to insert into Reservation table: " . $stmt->error);
    }
    $stmt = $conn->prepare("DELETE FROM Pending WHERE ID = ?");
    $stmt->bind_param("i", $reservationId);

    if (!$stmt->execute()) {
        throw new Exception("Failed to delete from Pending table: " . $stmt->error);
    }
    $conn->commit();
    echo json_encode(array('status' => 'success'));

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(array('status' => 'error', 'message' => $e->getMessage()));
}

$stmt->close();
$conn->close();
?>

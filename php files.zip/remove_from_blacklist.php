<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$customerId = $_POST['customerId'];
if (empty($customerId)) {
    echo json_encode(array("status" => "error", "message" => "Customer ID is required"));
    $conn->close();
    exit();
}
$sql = "DELETE FROM Black_List WHERE CID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $customerId);

if ($stmt->execute()) {
    echo json_encode(array("status" => "success", "message" => "User removed from blacklist successfully"));
} else {
    echo json_encode(array("status" => "error", "message" => "Error: " . $stmt->error));
}

$stmt->close();
$conn->close();
?>

<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$reservationId = $_POST['reservationId'];
$conn->begin_transaction();

try {
    $stmt = $conn->prepare("DELETE FROM Pending WHERE ID = ?");
    $stmt->bind_param("i", $reservationId);
    if (!$stmt->execute()) {
        throw new Exception("Failed to delete from Pending table: " . $stmt->error);
    }
    $conn->commit();
    echo json_encode(array('status' => 'success'));
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(array('status' => 'error', 'message' => $e->getMessage()));
}

$stmt->close();
$conn->close();
?>

<?php
$hostname = "localhost";
$database = "id22161597_carrentaldatabase";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$connection = new mysqli($hostname, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$email = $_POST['email'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$password = $_POST['password'];
if (empty($email) || empty($name) || empty($phone) || empty($password)) {
    echo json_encode(array("status" => "error", "message" => "All fields are required."));
    exit();
}

$checkEmailQuery = "SELECT * FROM Customer WHERE Email = '$email'";
$result = $connection->query($checkEmailQuery);
if ($result->num_rows > 0) {
    echo json_encode(array("status" => "error", "message" => "Email already exists."));
    exit();
}

function generateUniqueRandomId($connection) {
    do {
        $customerId = mt_rand(100000, 999999);
        $checkIdQuery = "SELECT * FROM Credentials WHERE ID = '$customerId'";
        $result = $connection->query($checkIdQuery);
    } while ($result->num_rows > 0);
    return $customerId;
}

$customerId = generateUniqueRandomId($connection);

$insertCustomerQuery = "INSERT INTO Customer (Email, Name, Phone, ID) VALUES ('$email', '$name', '$phone', '$customerId')";
if ($connection->query($insertCustomerQuery) === TRUE) {
    $insertCredentialsQuery = "INSERT INTO Credentials (ID, Password) VALUES ('$customerId', '$password')";
    if ($connection->query($insertCredentialsQuery) === TRUE) {
        echo json_encode(array("status" => "success", "message" => "User registered successfully.", "customerId" => $customerId));
    } else {
        echo json_encode(array("status" => "error", "message" => "Error inserting credentials."));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Error inserting customer."));
}

$connection->close();
?>

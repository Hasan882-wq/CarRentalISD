<?php
$hostname = "localhost";
$database = "id22161597_carrentaldatabase";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$conn = new mysqli($hostname, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Reservation.Id, Reservation.Days, Reservation.Price, 
               Customer.Name AS CustomerName, Customer.phone AS CustomerPhone, 
               Car.Image1 
        FROM Reservation
        JOIN Car ON Reservation.RID = Car.ID
        JOIN Customer ON Reservation.CID = Customer.ID";
$result = $conn->query($sql);

$reservations = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $imageFilename = $row['Image1'];
        $imagePath = 'https://carrentalisddatabaseh.000webhostapp.com/CarsIcons/' . $imageFilename;

        $reservationData = array(
            'Id' => $row['Id'],
            'Days' => $row['Days'],
            'Price' => $row['Price'],
            'CustomerName' => $row['CustomerName'],
            'CustomerPhone' => $row['CustomerPhone'],
            'Image1' => $imagePath,
        );

        $reservations[] = $reservationData;
    }
}
echo json_encode($reservations);

$conn->close();
?>

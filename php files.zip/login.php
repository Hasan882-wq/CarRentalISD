<?php
$hostname = "localhost";
$database = "id22161597_carrentaldatabase";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$conn = new mysqli($hostname, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$id = $_POST['id'];
$password = $_POST['password'];
$blackListCheckSql = "SELECT * FROM Black_List WHERE CID = '$id'";
$blackListResult = $conn->query($blackListCheckSql);

if ($blackListResult->num_rows > 0) {
    echo json_encode(array("status" => "error", "message" => "You are not able to use the app since you are in Black List. Please contact the company."));
} else {
    $credentialsCheckSql = "SELECT * FROM Credentials WHERE ID = '$id' And Password = '$password'";
    $credentialsResult = $conn->query($credentialsCheckSql);

    if ($credentialsResult->num_rows > 0) {
        $user = $credentialsResult->fetch_assoc();
        $userType = $user['user_type']; 
        if ($userType === '0') {
            echo json_encode(array("status" => "success", "user_type" => "customer"));
        } elseif ($userType === '1') {
            echo json_encode(array("status" => "success", "user_type" => "admin"));
        } else {
            echo json_encode(array("status" => "error", "message" => "Invalid user type"));
        }
    } else {
        echo json_encode(array("status" => "error", "message" => "Invalid credentials"));
    }
}
$conn->close();
?>

<?php
$hostname = "localhost";
$database = "id22161597_carrentaldatabase";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";

$conn = new mysqli($hostname, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$carId = isset($_POST['carId']) ? $conn->real_escape_string($_POST['carId']) : '';
if (empty($carId)) {
    die("Car ID is required.");
}
$sql = "DELETE FROM Out_Of_Order WHERE  CID = '$carId'";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully for Car ID: $carId";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>

<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$customerId = $_POST['customerId'];
$reason = $_POST['reason'];
if (empty($customerId) || empty($reason)) {
    echo json_encode(array("status" => "error", "message" => "Reason and Customer ID are required"));
    $conn->close();
    exit();
}

$blacklistId = rand(1, 99999); 
$sql = "INSERT INTO Black_List (ID, Reason, CID) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isi", $blacklistId, $reason, $customerId);

if ($stmt->execute()) {
    echo json_encode(array("status" => "success", "message" => "User blacklisted successfully"));
} else {
    echo json_encode(array("status" => "error", "message" => "Error: " . $stmt->error));
}

$stmt->close();
$conn->close();
?>

<?php
$hostname = "localhost";
$database = "id22161597_carrentaldatabase";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$conn = new mysqli($hostname, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$query = "SELECT ID,Title, News, IMG FROM News";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    $newsArray = array();
    while ($row = $result->fetch_assoc()) {
        $newsItem = array(
            'id' => $row['ID'],
            'title' => $row['Title'],
            'news' => $row['News'],
            'image' => getImageUrl($row['IMG']) 
        );
        $newsArray[] = $newsItem;
    }
    echo json_encode($newsArray);
} else {
    echo json_encode(array('message' => 'No news items found.'));
}
$conn->close();
function getImageUrl($imageName) {
    $baseUrl = 'https://carrentalisddatabaseh.000webhostapp.com/News/';
    $imageUrl = $baseUrl . $imageName;

    return $imageUrl;
}
?>

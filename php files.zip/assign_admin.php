<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$customerId = $_POST['customerId'];
$sql = "SELECT * FROM Customer WHERE ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $customerId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $customer = $result->fetch_assoc();
    $sql = "INSERT INTO Admin (ID, Name, Phone, Email) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $customer['ID'], $customer['Name'], $customer['Phone'], $customer['Email']);
    $stmt->execute();
    $sql = "UPDATE Credentials SET user_type = 1 WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customerId);
    $stmt->execute();
    $sql = "DELETE FROM Customer WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customerId);
    $stmt->execute();
    
    echo "User assigned as admin successfully";
} else {
    echo "Customer not found";
}

$stmt->close();
$conn->close();
?>

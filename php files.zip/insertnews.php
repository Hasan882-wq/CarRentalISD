<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$title = $_POST['title'];
$news = $_POST['news'];
$image = $_POST['image'];
$randomId = rand(1, 99999);
$sql = "INSERT INTO News (ID,Title, News, IMG) VALUES ('$randomId','$title', '$news', '$image')";

if ($conn->query($sql) === TRUE) {
    echo 'Data inserted successfully';
} else {
    echo 'Error inserting data: ' . $conn->error;
}

$conn->close();
?>

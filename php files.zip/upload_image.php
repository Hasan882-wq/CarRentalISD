<?php
if ($_FILES['image']['error'] == UPLOAD_ERR_OK && is_uploaded_file($_FILES['image']['tmp_name'])) {
    $uploadsDir = 'News/';
    $tempFile = $_FILES['image']['tmp_name'];
    $targetFile = $uploadsDir . basename($_FILES['image']['name']);
    if (move_uploaded_file($tempFile, $targetFile)) {
        echo basename($_FILES['image']['name']);
    } else {
        echo 'Error uploading image';
    }
} else {
    echo 'No image uploaded';
}
?>

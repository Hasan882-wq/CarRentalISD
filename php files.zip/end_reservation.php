<?php
// Database connection parameters
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reservationId = $_POST['reservationId'];
$sql = "INSERT INTO Reservation_History (ID, Days, Price, CID, RID)
        SELECT Id, Days, Price, CID, RID FROM Reservation WHERE Id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $reservationId);

if ($stmt->execute()) {
    $sql = "DELETE FROM Reservation WHERE Id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $reservationId);
    $stmt->execute();
}

$stmt->close();
$conn->close();
?>

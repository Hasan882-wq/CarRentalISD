<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reservationId = $_POST['reservationId'];
$newDays = $_POST['days'];
$newPrice = $_POST['price'];

$sql = "UPDATE Reservation SET Days = ?, Price = ? WHERE Id= ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("idi", $newDays, $newPrice, $reservationId);
$stmt->execute();

$stmt->close();
$conn->close();
?>

<?php
$servername = "localhost";
$username = "id22161597_carrentaldatabaseisd";
$password = "Hammoudd@81$";
$dbname = "id22161597_carrentaldatabase";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$customerId = $_POST['customerId'];
$carId = $_POST['carId'];
$days = $_POST['days'];
$price = $_POST['price'];
$paymentMethod = $_POST['paymentMethod'];
$randomId = rand(1, 99999);
$tprice = $price * $days;
$sql = "INSERT INTO Pending (ID, CID, RID, Days, Price) VALUES ('$randomId', '$customerId', '$carId', '$days', '$tprice')";

if ($conn->query($sql) === TRUE) {
    echo "Reservation successfully created";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>
